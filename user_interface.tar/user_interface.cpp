//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"
#include "user_interface.h"
#include "display.h"
#include "sensor_monitoring.h"
#include "ignition.h"
#include "ailerons.h"

//=====[Declaration of private defines]========================================

#define DISPLAY_REFRESH_TIME_MS 1000
#define TIME_INCREMENT_MS 10

//=====[Declarations (prototypes) of private functions]========================
DigitalIn displayChange(PD_3);

typedef enum {
    screen1,
    screen2,
} screenNumber;

static screenNumber ScreenType = screen1;
/**
 *  Initializes the LCD display for the system
 */
static void userInterfaceDisplayInit();

/**
 *  Updates the LCD display for the system
 */
static void userInterfaceDisplayUpdate();

//=====[Implementations of public functions]===================================

void userInterfaceInit()
{
    userInterfaceDisplayInit();
}

void userInterfaceUpdate()
{
    userInterfaceDisplayUpdate();

}

//=====[Implementations of private functions]===================================
static void getScreenNumber(){
    if (displayChange && (ScreenType == screen1)){
        ScreenType = screen2;
    }
    else if (displayChange && (ScreenType == screen2)){
        ScreenType = screen1;
    }
}
static void userInterfaceDisplayInit()
{
    displayInit();
    displayChange.mode(PullDown);
}

static void userInterfaceDisplayUpdate()
{
    static int accumulatedDisplayTime = 0;
    char temperatureString[3] = "";
    char speedString[3] = "";
    char angleString[3] = "";
    getScreenNumber();
    if( accumulatedDisplayTime >=
        DISPLAY_REFRESH_TIME_MS ) {
        accumulatedDisplayTime = 0;
        if (isIgnition()) {
            switch(ScreenType) {
                case screen1:
                    if ( gasDetection() ) {
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "     URGENT     " );
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "  GAS DETECTED  " );
                    } else {
                        sprintf(temperatureString, "%.0f", getTemperatureInCelsius());
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "Tmp:   " );
                        displayCharPositionWrite ( 4,0 );
                        displayStringWrite(temperatureString);
                        displayCharPositionWrite ( 7,0 );
                        displayStringWrite( "\xDF" );
                        displayCharPositionWrite ( 8,0 );
                        displayStringWrite( "C" );
                        displayCharPositionWrite ( 10,0 );
                        displayStringWrite( "Gas:ND" );
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "Engine Status:ON" );

                    }
                    break;
                case screen2:
                    if ( gasDetection() ) {
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "     URGENT     " );
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "  GAS DETECTED  " );
                    } else {

                        /**sprintf(speedString, "%.0f", motorSpeedInMph());
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "Speed:" );
                        displayCharPositionWrite ( 6,0 );
                        displayStringWrite(speedString);
                        displayCharPositionWrite ( 10,0 );
                        displayStringWrite( "mph  " );
                        **/
                        sprintf(angleString, "%.0f", servoAngle());
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "Alr angle:" );
                        displayCharPositionWrite ( 11,1 );
                        displayStringWrite( angleString );
                        displayCharPositionWrite ( 13,1 );
                        displayStringWrite( "\xDF" );
                        displayCharPositionWrite ( 14,1 );
                        displayStringWrite( "  " );

                    }
                    break;
               
            }   
        } else {
            displayCharPositionWrite ( 0,0 );
            displayStringWrite( "   Welcome to   " );
        
            displayCharPositionWrite ( 0,1 );
            displayStringWrite( "  the airplane  " );
        }
    } else {
        accumulatedDisplayTime = accumulatedDisplayTime + TIME_INCREMENT_MS;        
    } 
}