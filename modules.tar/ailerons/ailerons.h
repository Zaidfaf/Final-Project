
//=====[#include guards - begin]===============================================

#ifndef _AILERONS_H_
#define _AILERONS_H_

//=====[Declaration of public defines]=========================================

#define TIME_INCREMENT_MS   10

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void aileronsInit();
void aileronsUpdate();
float aileronsdegrees();
//=====[#include guards - end]=================================================

#endif // _AIRLERONS_H_