#include "mbed.h"
#include "arm_book_lib.h"
#include "sensor_monitoring.h"

#define NUMBER_OF_AVG_SAMPLES                   100

DigitalIn gasDetector(PE_12);
DigitalIn tempDetector(A1);
DigitalOut alarmLed(LED2);

float lm35ReadingsArray[NUMBER_OF_AVG_SAMPLES];
float lm35ReadingsAverage = 0;
float lm35TempC = 0;
float lm35ReadingsSum = 0;

static void sensorMonitoringInit();



static void sensorMonitoringInit(){
    gasDetector.mode(PullDown);
    alarmLed = OFF;
    void lm35ReadingsArrayInit();
}
void lm35ReadingsArrayInit()
{
    int i;
    for( i=0; i<NUMBER_OF_AVG_SAMPLES ; i++ ) {
        lm35ReadingsArray[i] = 0;
    }
}
float getTemperatureInCelsius(){
    static int lm35SampleIndex = 0;
    int i = 0;

    lm35ReadingsArray[lm35SampleIndex] = tempDetector.read();
    lm35SampleIndex++;
    if ( lm35SampleIndex >= NUMBER_OF_AVG_SAMPLES) {
        lm35SampleIndex = 0;
    }
    
    lm35ReadingsSum = 0.0;
    for (i = 0; i < NUMBER_OF_AVG_SAMPLES; i++) {
        lm35ReadingsSum = lm35ReadingsSum + lm35ReadingsArray[i];
    }
    lm35ReadingsAverage = lm35ReadingsSum / NUMBER_OF_AVG_SAMPLES;
       lm35TempC = analogReadingScaledWithTheLM35Formula ( lm35ReadingsAverage );
       return lm35TempC;    
}
float analogReadingScaledWithTheLM35Formula( float analogReading )
{
    return ( analogReading * 3.3 / 0.01 );
}

bool gasDetection(){
    if (gasDetector){
        alarmLed = ON;
        return true;
    }
    else{
        alarmLed = OFF;
        return false;
    }
}
