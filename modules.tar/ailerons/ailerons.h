//=====[#include guards - begin]===============================================

#ifndef _AILERONS_H_
#define _AILERONS_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================


//=====[Declarations (prototypes) of public functions]=========================

void aileronsInit();

void aileronsUpdate();

float servoAngle();

//=====[#include guards - end]=================================================

#endif // _AILERONS_H_