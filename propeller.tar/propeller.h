//=====[#include guards - begin]===============================================

#ifndef _PROPELLER_H_
#define _PROPELLER_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void propellerInit();
void propellerUpdate();
/**
 *  Sets the speed of the motor given some rpm
 */


void setSpeed(int rpm);

/**
 *  Sets the target angle for the servo to turn to
 */
void setAngle(int degrees);

//=====[#include guards - end]=================================================

#endif // _SERVO_MOTOR_H_