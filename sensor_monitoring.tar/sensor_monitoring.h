//=====[#include guards - begin]===============================================

#ifndef _SENSOR_MONITORING_H_
#define _SENSOR_MONITORING_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

bool gasDetection();

float getTemperatureInCelsius();

void lm35ReadingsArrayInit();

float analogReadingScaledWithTheLM35Formula( float analogReading );

//=====[#include guards - end]=================================================

#endif // _SENSOR_MONITORING_H_